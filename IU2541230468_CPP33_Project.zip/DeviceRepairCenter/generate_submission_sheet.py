import os
from PIL import Image, ImageDraw, ImageFont
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
import zipfile

BASE_DIR = r"c:\Users\91971\Downloads\IU2541230468_CPP33_Project\DeviceRepairCenter"
PARENT_DIR = r"c:\Users\91971\Downloads\IU2541230468_CPP33_Project"

# ==========================================
# 1. CREATE WORD DOCUMENT (.DOCX)
# ==========================================
print("Generating Word Document (.docx)...")
doc = docx.Document()

# Page Margins
sections = doc.sections
for section in sections:
    section.top_margin = Inches(1.0)
    section.bottom_margin = Inches(1.0)
    section.left_margin = Inches(1.0)
    section.right_margin = Inches(1.0)

blue_color = RGBColor(0x2E, 0x75, 0xB6) # Standard Word theme blue

# Title: FINAL SUBMISSION
p_title = doc.add_paragraph()
r_title = p_title.add_run("FINAL SUBMISSION")
r_title.bold = True
r_title.font.name = "Calibri"
r_title.font.size = Pt(20)
r_title.font.color.rgb = RGBColor(0x11, 0x18, 0x27)
p_title.paragraph_format.space_after = Pt(16)

# Section 1: Student Information
p_h1 = doc.add_paragraph()
r_h1 = p_h1.add_run("Student Information")
r_h1.bold = True
r_h1.font.name = "Calibri"
r_h1.font.size = Pt(13)
r_h1.font.color.rgb = blue_color
p_h1.paragraph_format.space_after = Pt(4)

p_info = doc.add_paragraph()
p_info.paragraph_format.space_after = Pt(14)
p_info.paragraph_format.line_spacing = 1.3
r_enr = p_info.add_run("Enrollment Number: IU2541230468\n\nProject Code: CPP33\n\nProject Name: Device Repair Center")
r_enr.font.name = "Calibri"
r_enr.font.size = Pt(11)

# Section 2: Final Submission Checklist
p_h2 = doc.add_paragraph()
r_h2 = p_h2.add_run("Final Submission Checklist")
r_h2.bold = True
r_h2.font.name = "Calibri"
r_h2.font.size = Pt(13)
r_h2.font.color.rgb = blue_color
p_h2.paragraph_format.space_after = Pt(6)

checklist = [
    "Source folder with main.cpp and modular .h/.cpp files",
    "Data folder containing sample/generated data files",
    "Use Case Diagram",
    "Class Diagram",
    "Sequence Diagram 1",
    "Sequence Diagram 2",
    "Working executable",
    "Screenshots",
    "README.txt",
    "ProjectReport.pdf"
]

for item in checklist:
    p_item = doc.add_paragraph()
    p_item.paragraph_format.space_after = Pt(3)
    r_check = p_item.add_run("✔ ")
    r_check.bold = True
    r_check.font.name = "Segoe UI Symbol"
    r_check.font.size = Pt(11)
    r_text = p_item.add_run(item)
    r_text.font.name = "Calibri"
    r_text.font.size = Pt(11)

doc.add_paragraph().paragraph_format.space_after = Pt(6)

# Section 3: Final ZIP Naming
p_h3 = doc.add_paragraph()
r_h3 = p_h3.add_run("Final ZIP Naming")
r_h3.bold = True
r_h3.font.name = "Calibri"
r_h3.font.size = Pt(13)
r_h3.font.color.rgb = blue_color
p_h3.paragraph_format.space_after = Pt(4)

p_zip = doc.add_paragraph()
p_zip.paragraph_format.space_after = Pt(14)
r_zip = p_zip.add_run("IU2541230468_CPP33_Project.zip")
r_zip.font.name = "Calibri"
r_zip.font.size = Pt(11)

# Section 4: Final Verification
p_h4 = doc.add_paragraph()
r_h4 = p_h4.add_run("Final Verification")
r_h4.bold = True
r_h4.font.name = "Calibri"
r_h4.font.size = Pt(13)
r_h4.font.color.rgb = blue_color
p_h4.paragraph_format.space_after = Pt(4)

p_ver = doc.add_paragraph()
r_ver = p_ver.add_run("Run the executable from the final submission folder. Verify add, display, search, update, delete, main transaction, report and save/load operations. Close and reopen the program and confirm that saved data is still available")
r_ver.font.name = "Calibri"
r_ver.font.size = Pt(11)

docx_path = os.path.join(BASE_DIR, "IU2541230468_CPP33_Submission_Template.docx")
doc.save(docx_path)
print(f"Docx saved: {docx_path}")


# ==========================================
# 2. CREATE PDF DOCUMENT (.PDF)
# ==========================================
print("Generating PDF Document (.pdf)...")
pdf_path = os.path.join(BASE_DIR, "IU2541230468_CPP33_Submission_Template.pdf")

doc_pdf = SimpleDocTemplate(
    pdf_path,
    pagesize=letter,
    leftMargin=72,
    rightMargin=72,
    topMargin=72,
    bottomMargin=72
)

styles = getSampleStyleSheet()

t_style = ParagraphStyle(
    "TitleStyle",
    parent=styles["Normal"],
    fontName="Helvetica-Bold",
    fontSize=20,
    leading=24,
    textColor=colors.HexColor("#111827"),
    spaceAfter=18
)

h_blue = ParagraphStyle(
    "HeaderBlue",
    parent=styles["Normal"],
    fontName="Helvetica-Bold",
    fontSize=13,
    leading=17,
    textColor=colors.HexColor("#2E75B6"),
    spaceBefore=10,
    spaceAfter=5
)

body = ParagraphStyle(
    "BodyText",
    parent=styles["Normal"],
    fontName="Helvetica",
    fontSize=10.5,
    leading=15,
    textColor=colors.HexColor("#1F2937"),
    spaceAfter=8
)

chk_style = ParagraphStyle(
    "ChecklistText",
    parent=styles["Normal"],
    fontName="Helvetica",
    fontSize=10.5,
    leading=14.5,
    textColor=colors.HexColor("#1F2937"),
    spaceAfter=3,
    leftIndent=15,
    firstLineIndent=-15
)

story = []
story.append(Paragraph("FINAL SUBMISSION", t_style))

story.append(Paragraph("Student Information", h_blue))
story.append(Paragraph("Enrollment Number: IU2541230468", body))
story.append(Paragraph("Project Code: CPP33", body))
story.append(Paragraph("Project Name: Device Repair Center", body))
story.append(Spacer(1, 6))

story.append(Paragraph("Final Submission Checklist", h_blue))
for item in checklist:
    story.append(Paragraph(f"<b>&#10004;</b> &nbsp; {item}", chk_style))
story.append(Spacer(1, 8))

story.append(Paragraph("Final ZIP Naming", h_blue))
story.append(Paragraph("IU2541230468_CPP33_Project.zip", body))
story.append(Spacer(1, 6))

story.append(Paragraph("Final Verification", h_blue))
story.append(Paragraph(
    "Run the executable from the final submission folder. Verify add, display, search, update, delete, main transaction, report and save/load operations. Close and reopen the program and confirm that saved data is still available",
    body
))

doc_pdf.build(story)
print(f"PDF saved: {pdf_path}")


# ==========================================
# 3. CREATE HIGH-RES IMAGE (.PNG)
# ==========================================
print("Generating High-Resolution Image (.png)...")

W, H = 1000, 1150
img = Image.new("RGB", (W, H), "#FFFFFF")
d = ImageDraw.Draw(img)

def gf(size, bold=False):
    try:
        return ImageFont.truetype("arialbd.ttf" if bold else "arial.ttf", size)
    except:
        return ImageFont.load_default()

def gf_symbol(size):
    try:
        return ImageFont.truetype("seguisym.ttf", size)
    except:
        return gf(size, True)

x_margin = 120
y = 100

# Title
d.text((x_margin, y), "FINAL SUBMISSION", fill="#111827", font=gf(26, True))
y += 65

# Section 1
d.text((x_margin, y), "Student Information", fill="#2E75B6", font=gf(16, True))
y += 32
d.text((x_margin, y), "Enrollment Number: IU2541230468", fill="#1F2937", font=gf(14))
y += 36
d.text((x_margin, y), "Project Code: CPP33", fill="#1F2937", font=gf(14))
y += 36
d.text((x_margin, y), "Project Name: Device Repair Center", fill="#1F2937", font=gf(14))
y += 55

# Section 2
d.text((x_margin, y), "Final Submission Checklist", fill="#2E75B6", font=gf(16, True))
y += 32

for item in checklist:
    # draw checkmark
    d.text((x_margin, y), "✔", fill="#111827", font=gf_symbol(15))
    d.text((x_margin + 26, y), item, fill="#1F2937", font=gf(14))
    y += 28

y += 28

# Section 3
d.text((x_margin, y), "Final ZIP Naming", fill="#2E75B6", font=gf(16, True))
y += 32
d.text((x_margin, y), "IU2541230468_CPP33_Project.zip", fill="#1F2937", font=gf(14))
y += 50

# Section 4
d.text((x_margin, y), "Final Verification", fill="#2E75B6", font=gf(16, True))
y += 30

ver_text_line1 = "Run the executable from the final submission folder. Verify add, display, search, update,"
ver_text_line2 = "delete, main transaction, report and save/load operations. Close and reopen the program"
ver_text_line3 = "and confirm that saved data is still available"

d.text((x_margin, y), ver_text_line1, fill="#1F2937", font=gf(13))
y += 22
d.text((x_margin, y), ver_text_line2, fill="#1F2937", font=gf(13))
y += 22
d.text((x_margin, y), ver_text_line3, fill="#1F2937", font=gf(13))

png_path = os.path.join(BASE_DIR, "IU2541230468_CPP33_Submission_Template.png")
img.save(png_path)
print(f"PNG saved: {png_path}")


# ==========================================
# 4. UPDATE FINAL SUBMISSION ZIP
# ==========================================
print("Updating IU2541230468_CPP33_Project.zip...")

zip_dest = os.path.join(PARENT_DIR, "IU2541230468_CPP33_Project.zip")

with zipfile.ZipFile(zip_dest, "w", zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(BASE_DIR):
        for f in files:
            full_p = os.path.join(root, f)
            rel_p = os.path.relpath(full_p, BASE_DIR)
            zf.write(full_p, os.path.join("DeviceRepairCenter", rel_p))

print(f"Updated ZIP at: {zip_dest} (Size: {os.path.getsize(zip_dest)} bytes)")
print("ALL SUBMISSION TEMPLATE GENERATION COMPLETE!")
